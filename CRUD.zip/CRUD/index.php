<?php
  // Info Koneksi
  $server = "localhost";
  $user = "root";
  $pass = "";
  $database = "pijarcamp";

  // Mulai Koneksi
  $koneksi = mysqli_connect($server, $user, $pass, $database)or die(mysqli_error($koneksi));

  // Simpan Data
  if(isset($_POST['bsave'])){
    // Edit atau Submit Baru
    if ($_GET['hal'] == "edit") {
      // Data diedit
      $edit = mysqli_query($koneksi, "UPDATE  produk set
                                      nama_produk = '$_POST[dnama]',
                                      keterangan = '$_POST[dket]',
                                      harga = '$_POST[dhar]',
                                      jumlah = '$_POST[djum]'
                                      WHERE id_produk= '$_GET[id]'
                                     ");
      if($edit) //jika edit sukses
      {
        echo "<script>
            alert('Edit berhasil!');
            document.location='index.php';
             </script>";
      }
      else
      {
        echo "<script>
            alert('Edit gagal!!');
            document.location='index.php';
             </script>";
      }
    }
    else{
      // Data disubmit
      $save = mysqli_query($koneksi, "INSERT INTO produk (nama_produk, keterangan, harga, jumlah) VALUES ('$_POST[dnama]','$_POST[dket]','$_POST[dhar]','$_POST[djum]')");
      if($save) //jika edit sukses
      {
        echo "<script>
            alert('Submit berhasil!');
            document.location='index.php';
             </script>";
      }
      else
      {
        echo "<script>
            alert('Submit gagal!!');
            document.location='index.php';
             </script>";
      }
    }
  }

  // Edit-Hapus Data
  if(isset($_GET['hal'])){
    if ($_GET['hal'] == "edit") {
      $show = mysqli_query($koneksi, "SELECT * FROM produk WHERE id_produk = '$_GET[id]'");
      $data = mysqli_fetch_array($show);
      if ($data) {
        $vnama = $data['nama_produk'];
        $vket = $data['keterangan'];
        $vhar = $data['harga'];
        $vjum = $data['jumlah'];
      }
    }
    else if ($_GET['hal'] == "delete"){
      $hapus  = mysqli_query($koneksi, "DELETE FROM produk WHERE id_produk = '$_GET[id]'");
    }
  }

?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>CRUD Test</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
  <div class="container">
    <h1 class="display-4 text-center" style="padding-top: 50px;">Data Produk</h1>
    <!--     Awal Form  -->
    <div class="card" style="margin-top: 100px;">
      <div class="card-header bg-grey">
        Produk
      </div>
      <div class="card-body">
        <form method="post" action="">
          <div class="form-group">
            <label>Nama Produk</label>
            <input type="text" name="dnama" value="<?=@$vnama?>" class="form-control" placeholder="Masukkan nama produk di sini">
          </div>
          <div class="form-group">
            <label>Keterangan</label>
            <input type="text" name="dket" value="<?=@$vket?>"class="form-control" placeholder="Masukkan keterangan produk di sini">
          </div>
          <div class="form-group">
            <label>Harga</label>
            <input type="text" name="dhar" value="<?=@$vhar?>" class="form-control" placeholder="Masukkan nama produk di sini">
          </div>
          <div class="form-group">
            <label>Jumlah</label>
            <input type="text" name="djum" value="<?=@$vjum?>" class="form-control" placeholder="Masukkan nama produk di sini">
          </div>
          <button type="submit" class="btn btn-primary" name="bsave">Submit</button>
          <a href="index.php" class="btn btn-secondary" name="breset">Reset</a>
        </form>
      </div>
    </div>
    <!--     Awal Tabel -->
    <div class="card" style="margin-top: 50px;">
      <div class="card-header bg-grey">
        Daftar Produk
      </div>
      <div class="card-body">
        <table class="table table-bordered table-striped">
          <tr>
            <th>No.</th>
            <th>Nama Produk</th>
            <th>Keterangan</th>
            <th>Harga</th>
            <th>Jumlah</th>
            <th>Tindakan</th>
          </tr>
          <?php
            $no = 1;
            $query = mysqli_query($koneksi, "SELECT * from produk order by id_produk desc");
            while($data = mysqli_fetch_array($query)) :
          ?>
          <tr>
            <td>
              <?=$no++;?>
            </td>
            <td>
              <?=$data['nama_produk']?>
            </td>
            <td>
              <?=$data['keterangan']?>
            </td>
            <td>
              <?=$data['harga']?>
            </td>
            <td>
              <?=$data['jumlah']?>
            </td>
            <td>
              <a href="index.php?hal=edit&id=<?=$data['id_produk']?>" class="btn btn-warning"> Edit </a>
              <a href="index.php?hal=delete&id=<?=$data['id_produk']?>" onclick="return confirm('Hapus data ini?')" class="btn btn-danger"> Hapus </a>
            </td>
          </tr>
          <?php endwhile; ?>
        </table>
      </div>
    </div>
  </div>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>

</html>